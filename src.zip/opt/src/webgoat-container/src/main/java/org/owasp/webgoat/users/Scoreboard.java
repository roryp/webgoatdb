package org.owasp.webgoat.users;

import org.owasp.webgoat.i18n.PluginMessages;
import org.owasp.webgoat.session.Course;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Temp endpoint just for the CTF.
 *
 * @author nbaars
 * @since 3/23/17.
 */
@RestController
public class Scoreboard {
	private final UserTrackerRepository userTrackerRepository;
	private final UserRepository userRepository;
	private final Course course;
	private final PluginMessages pluginMessages;


	private class Ranking {
		private String username;
		private List<String> flagsCaptured;

		@java.lang.SuppressWarnings("all")
		public Ranking(final String username, final List<String> flagsCaptured) {
			this.username = username;
			this.flagsCaptured = flagsCaptured;
		}

		@java.lang.SuppressWarnings("all")
		public String getUsername() {
			return this.username;
		}

		@java.lang.SuppressWarnings("all")
		public List<String> getFlagsCaptured() {
			return this.flagsCaptured;
		}
	}

	@GetMapping("/scoreboard-data")
	public List<Ranking> getRankings() {
		List<WebGoatUser> allUsers = userRepository.findAll();
		List<Ranking> rankings = new ArrayList<>();
		for (WebGoatUser user : allUsers) {
			if (user.getUsername().startsWith("csrf-")) {
				//the csrf- assignment specific users do not need to be in the overview
				continue;
			}
			UserTracker userTracker = userTrackerRepository.findByUser(user.getUsername());
			rankings.add(new Ranking(user.getUsername(), challengesSolved(userTracker)));
		}
		/* sort on number of captured flags to present an ordered ranking */
		rankings.sort(new Comparator<Ranking>() {
			@Override
			public int compare(Ranking o1, Ranking o2) {
				return o2.getFlagsCaptured().size() - o1.getFlagsCaptured().size();
			}
		});
		return rankings;
	}

	private List<String> challengesSolved(UserTracker userTracker) {
		List<String> challenges = List.of("Challenge1", "Challenge2", "Challenge3", "Challenge4", "Challenge5", "Challenge6", "Challenge7", "Challenge8", "Challenge9");
		return challenges.stream().map(c -> userTracker.getLessonTracker(c)).filter(l -> l.isPresent()).map(l -> l.get()).filter(l -> l.isLessonSolved()).map(l -> l.getLessonName()).map(l -> toLessonTitle(l)).collect(Collectors.toList());
	}

	private String toLessonTitle(String id) {
		String titleKey = course.getLessons().stream().filter(l -> l.getId().equals(id)).findFirst().get().getTitle();
		return pluginMessages.getMessage(titleKey, titleKey);
	}

	@java.lang.SuppressWarnings("all")
	public Scoreboard(final UserTrackerRepository userTrackerRepository, final UserRepository userRepository, final Course course, final PluginMessages pluginMessages) {
		this.userTrackerRepository = userTrackerRepository;
		this.userRepository = userRepository;
		this.course = course;
		this.pluginMessages = pluginMessages;
	}
}
