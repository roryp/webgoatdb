package org.owasp.webgoat.users;

import org.springframework.data.annotation.Id;

/**
 * @author nbaars
 * @since 8/15/17.
 */
public class UserSession {
    private WebGoatUser webGoatUser;
    @Id
    private String sessionId;

    @java.lang.SuppressWarnings("all")
    public WebGoatUser getWebGoatUser() {
        return this.webGoatUser;
    }

    @java.lang.SuppressWarnings("all")
    public String getSessionId() {
        return this.sessionId;
    }

    @java.lang.SuppressWarnings("all")
    public UserSession(final WebGoatUser webGoatUser, final String sessionId) {
        this.webGoatUser = webGoatUser;
        this.sessionId = sessionId;
    }

    @java.lang.SuppressWarnings("all")
    protected UserSession() {
    }
}
