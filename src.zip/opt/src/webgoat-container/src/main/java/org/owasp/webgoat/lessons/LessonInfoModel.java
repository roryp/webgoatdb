package org.owasp.webgoat.lessons;

/**
 * <p>LessonInfoModel class.</p>
 *
 * @author dm
 * @version $Id: $Id
 */
public class LessonInfoModel {
    private String lessonTitle;
    private boolean hasSource;
    private boolean hasSolution;
    private boolean hasPlan;

    @java.lang.SuppressWarnings("all")
    public String getLessonTitle() {
        return this.lessonTitle;
    }

    @java.lang.SuppressWarnings("all")
    public boolean isHasSource() {
        return this.hasSource;
    }

    @java.lang.SuppressWarnings("all")
    public boolean isHasSolution() {
        return this.hasSolution;
    }

    @java.lang.SuppressWarnings("all")
    public boolean isHasPlan() {
        return this.hasPlan;
    }

    @java.lang.SuppressWarnings("all")
    public LessonInfoModel(final String lessonTitle, final boolean hasSource, final boolean hasSolution, final boolean hasPlan) {
        this.lessonTitle = lessonTitle;
        this.hasSource = hasSource;
        this.hasSolution = hasSolution;
        this.hasPlan = hasPlan;
    }
}
