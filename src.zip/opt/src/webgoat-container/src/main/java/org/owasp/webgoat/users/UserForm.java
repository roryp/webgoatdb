package org.owasp.webgoat.users;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * @author nbaars
 * @since 3/19/17.
 */
public class UserForm {
    @NotNull
    @Size(min = 6, max = 45)
    @Pattern(regexp = "[a-z0-9-]*", message = "can only contain lowercase letters, digits, and -")
    private String username;
    @NotNull
    @Size(min = 6, max = 10)
    private String password;
    @NotNull
    @Size(min = 6, max = 10)
    private String matchingPassword;
    @NotNull
    private String agree;

    @java.lang.SuppressWarnings("all")
    public String getUsername() {
        return this.username;
    }

    @java.lang.SuppressWarnings("all")
    public String getPassword() {
        return this.password;
    }

    @java.lang.SuppressWarnings("all")
    public String getMatchingPassword() {
        return this.matchingPassword;
    }

    @java.lang.SuppressWarnings("all")
    public String getAgree() {
        return this.agree;
    }

    @java.lang.SuppressWarnings("all")
    public void setUsername(final String username) {
        this.username = username;
    }

    @java.lang.SuppressWarnings("all")
    public void setPassword(final String password) {
        this.password = password;
    }

    @java.lang.SuppressWarnings("all")
    public void setMatchingPassword(final String matchingPassword) {
        this.matchingPassword = matchingPassword;
    }

    @java.lang.SuppressWarnings("all")
    public void setAgree(final String agree) {
        this.agree = agree;
    }
}
