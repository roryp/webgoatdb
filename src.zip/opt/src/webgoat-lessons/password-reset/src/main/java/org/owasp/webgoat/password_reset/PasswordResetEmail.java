/*
 * This file is part of WebGoat, an Open Web Application Security Project utility. For details, please see http://www.owasp.org/
 *
 * Copyright (c) 2002 - 2019 Bruce Mayhew
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if
 * not, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 * Getting Source ==============
 *
 * Source for this application is maintained at https://github.com/WebGoat/WebGoat, a repository for free software projects.
 */
package org.owasp.webgoat.password_reset;

import java.io.Serializable;
import java.time.LocalDateTime;

public class PasswordResetEmail implements Serializable {
    private LocalDateTime time;
    private String contents;
    private String sender;
    private String title;
    private String recipient;

    @java.lang.SuppressWarnings("all")
    PasswordResetEmail(final LocalDateTime time, final String contents, final String sender, final String title, final String recipient) {
        this.time = time;
        this.contents = contents;
        this.sender = sender;
        this.title = title;
        this.recipient = recipient;
    }


    @java.lang.SuppressWarnings("all")
    public static class PasswordResetEmailBuilder {
        @java.lang.SuppressWarnings("all")
        private LocalDateTime time;
        @java.lang.SuppressWarnings("all")
        private String contents;
        @java.lang.SuppressWarnings("all")
        private String sender;
        @java.lang.SuppressWarnings("all")
        private String title;
        @java.lang.SuppressWarnings("all")
        private String recipient;

        @java.lang.SuppressWarnings("all")
        PasswordResetEmailBuilder() {
        }

        /**
         * @return {@code this}.
         */
        @java.lang.SuppressWarnings("all")
        public PasswordResetEmail.PasswordResetEmailBuilder time(final LocalDateTime time) {
            this.time = time;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @java.lang.SuppressWarnings("all")
        public PasswordResetEmail.PasswordResetEmailBuilder contents(final String contents) {
            this.contents = contents;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @java.lang.SuppressWarnings("all")
        public PasswordResetEmail.PasswordResetEmailBuilder sender(final String sender) {
            this.sender = sender;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @java.lang.SuppressWarnings("all")
        public PasswordResetEmail.PasswordResetEmailBuilder title(final String title) {
            this.title = title;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @java.lang.SuppressWarnings("all")
        public PasswordResetEmail.PasswordResetEmailBuilder recipient(final String recipient) {
            this.recipient = recipient;
            return this;
        }

        @java.lang.SuppressWarnings("all")
        public PasswordResetEmail build() {
            return new PasswordResetEmail(this.time, this.contents, this.sender, this.title, this.recipient);
        }

        @java.lang.Override
        @java.lang.SuppressWarnings("all")
        public java.lang.String toString() {
            return "PasswordResetEmail.PasswordResetEmailBuilder(time=" + this.time + ", contents=" + this.contents + ", sender=" + this.sender + ", title=" + this.title + ", recipient=" + this.recipient + ")";
        }
    }

    @java.lang.SuppressWarnings("all")
    public static PasswordResetEmail.PasswordResetEmailBuilder builder() {
        return new PasswordResetEmail.PasswordResetEmailBuilder();
    }

    @java.lang.SuppressWarnings("all")
    public LocalDateTime getTime() {
        return this.time;
    }

    @java.lang.SuppressWarnings("all")
    public String getContents() {
        return this.contents;
    }

    @java.lang.SuppressWarnings("all")
    public String getSender() {
        return this.sender;
    }

    @java.lang.SuppressWarnings("all")
    public String getTitle() {
        return this.title;
    }

    @java.lang.SuppressWarnings("all")
    public String getRecipient() {
        return this.recipient;
    }

    @java.lang.SuppressWarnings("all")
    public void setTime(final LocalDateTime time) {
        this.time = time;
    }

    @java.lang.SuppressWarnings("all")
    public void setContents(final String contents) {
        this.contents = contents;
    }

    @java.lang.SuppressWarnings("all")
    public void setSender(final String sender) {
        this.sender = sender;
    }

    @java.lang.SuppressWarnings("all")
    public void setTitle(final String title) {
        this.title = title;
    }

    @java.lang.SuppressWarnings("all")
    public void setRecipient(final String recipient) {
        this.recipient = recipient;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("all")
    public boolean equals(final java.lang.Object o) {
        if (o == this) return true;
        if (!(o instanceof PasswordResetEmail)) return false;
        final PasswordResetEmail other = (PasswordResetEmail) o;
        if (!other.canEqual((java.lang.Object) this)) return false;
        final java.lang.Object this$time = this.getTime();
        final java.lang.Object other$time = other.getTime();
        if (this$time == null ? other$time != null : !this$time.equals(other$time)) return false;
        final java.lang.Object this$contents = this.getContents();
        final java.lang.Object other$contents = other.getContents();
        if (this$contents == null ? other$contents != null : !this$contents.equals(other$contents)) return false;
        final java.lang.Object this$sender = this.getSender();
        final java.lang.Object other$sender = other.getSender();
        if (this$sender == null ? other$sender != null : !this$sender.equals(other$sender)) return false;
        final java.lang.Object this$title = this.getTitle();
        final java.lang.Object other$title = other.getTitle();
        if (this$title == null ? other$title != null : !this$title.equals(other$title)) return false;
        final java.lang.Object this$recipient = this.getRecipient();
        final java.lang.Object other$recipient = other.getRecipient();
        if (this$recipient == null ? other$recipient != null : !this$recipient.equals(other$recipient)) return false;
        return true;
    }

    @java.lang.SuppressWarnings("all")
    protected boolean canEqual(final java.lang.Object other) {
        return other instanceof PasswordResetEmail;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("all")
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final java.lang.Object $time = this.getTime();
        result = result * PRIME + ($time == null ? 43 : $time.hashCode());
        final java.lang.Object $contents = this.getContents();
        result = result * PRIME + ($contents == null ? 43 : $contents.hashCode());
        final java.lang.Object $sender = this.getSender();
        result = result * PRIME + ($sender == null ? 43 : $sender.hashCode());
        final java.lang.Object $title = this.getTitle();
        result = result * PRIME + ($title == null ? 43 : $title.hashCode());
        final java.lang.Object $recipient = this.getRecipient();
        result = result * PRIME + ($recipient == null ? 43 : $recipient.hashCode());
        return result;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("all")
    public java.lang.String toString() {
        return "PasswordResetEmail(time=" + this.getTime() + ", contents=" + this.getContents() + ", sender=" + this.getSender() + ", title=" + this.getTitle() + ", recipient=" + this.getRecipient() + ")";
    }
}
